const titleInput = document.querySelector("input#title");
const descInput = document.querySelector("input#desc");
const addBtn = document.querySelector("#addBtn");
const tblBody = document.querySelector("#tblBody");

document.querySelector("button#cancel").addEventListener("click",function () {
  document.querySelector("div#editForm input").value ="";
  document.querySelector("div#editForm textarea").value ="";
  document.querySelector("div#editForm").style.display="none";
})

/* Check if todo exists or add one */
if (!localStorage.getItem('todo')) {
  let mkArray = new Array();
  localStorage.setItem("todo", JSON.stringify(mkArray));

}



const loopTodos = () => {



  // Empty table first
  tblBody.innerHTML = "";
 

   

  let currentItems = JSON.parse(localStorage.getItem("todo"));
  // localStorage.setItem('todo',JSON.stringify(currentItems));
  /*  loop through localstorage*/
  let serial = 1;
  currentItems.forEach((value, index) => {
    tblBody.innerHTML += `<tr id="singleTodo" data-itemId ="${index}">
        <td>${serial}</td>
        <td>${value.title}</td>
        <td>${value.desc}</td>
        <td>
            <button  id="editBtn" class="btn btn-edit">Edit</button>
            <button " id="dltBtn" class="btn btn-dlt">Delete</button>
        </td>
        </tr>`;


      

    serial++;
  });

  deleteTodo(); 
  modifyTodo ();
   let cItems = JSON.parse(localStorage.getItem('todo'));

  if (cItems.length === 0) {
   document.querySelector("table thead").setAttribute("style","display:none")
    document.querySelector("#emptyMsg").innerHTML ="There is no todo";
  }else{
    document.querySelector("table thead").removeAttribute('style');
    document.querySelector("#emptyMsg").innerHTML ="";
  };
};


const addTodo = () => {
  addBtn.addEventListener("click", function () {
    let todoTitle = titleInput.value.trim();
    let tododesc = descInput.value.trim();

    let newTodo = {
      title: todoTitle,
      desc: tododesc
    }
    // Get  current Items
    let currentTodos = JSON.parse(localStorage.getItem('todo'));
    currentTodos.push(newTodo);
    localStorage.clear();
    // setItem again
    localStorage.setItem("todo", JSON.stringify(currentTodos))
    // emty input boxes
    titleInput.value = "";
    descInput.value = "";



    //  loop table again
    loopTodos();
    modifyTodo ();
  })
}







loopTodos();

function deleteTodo (){
  /* DELETE AND EDIT BUTTON */
const allTodos= document.querySelectorAll("#singleTodo");

allTodos.forEach((todo) =>{
 todo.querySelector("#dltBtn").addEventListener("click",function () {
   
  let currentItems =JSON.parse(localStorage.getItem("todo"));
  let clickedIndex = Number(todo.getAttribute("data-itemId"));
  let remainingItems =currentItems.filter((item,index) => {
return index !== clickedIndex 

  });
 
// clear the localStorage
localStorage.clear();
localStorage.setItem("todo",JSON.stringify( remainingItems));
// loop strat
loopTodos();

 });
});

}
deleteTodo(); 
function modifyTodo (){
  /* DELETE AND EDIT BUTTON */
const allTodos= document.querySelectorAll("#singleTodo");

allTodos.forEach((todo) =>{
 todo.querySelector("#editBtn").addEventListener("click",function () {
   
  let currentItems =JSON.parse(localStorage.getItem("todo"));
  let clickedIndex = Number(todo.getAttribute("data-itemId"));

 
  document.querySelector("#Edittitle").value = currentItems[clickedIndex].title;
 document.querySelector("#Editdesc").value = currentItems[clickedIndex].desc;
 document.querySelector("div#editForm").style.display ="block";

  document.querySelector("#arrayIndex").value = clickedIndex;
// clear the localStorage
// localStorage.clear();
// localStorage.setItem("todo",JSON.stringify( modifiedItems));
// loop strat
// loopTodos();

 });
});
// loopTodos();
};

modifyTodo ();


function updateTodo() {
  document.querySelector("#update").addEventListener("click", function () {
    let currentItems =JSON.parse(localStorage.getItem("todo"));
    let editTitle =document.querySelector("#Edittitle").value;
    let editDesc =document.querySelector("#Editdesc").value;
    let editObj = {
      title:editTitle,
      desc:editDesc,
    }
    let updateIndex =Number(document.querySelector("#arrayIndex").value);
  
     currentItems[updateIndex]=editObj; 
    localStorage.clear();
    localStorage.setItem("todo",JSON.stringify(currentItems));
    document.querySelector("div#editForm input").value ="";
  document.querySelector("div#editForm textarea").value ="";
  document.querySelector("div#editForm").style.display="none";
 
    loopTodos();
  });


}

updateTodo()

addTodo();










































































/* Check if todo exists or add one */
// if (!localStorage.getItem('todo')) {
//   let mkArray= new Array();
//   localStorage.setItem("todo",JSON.stringify(mkArray));
// }

// let cucurrentItem=JSON.parse(localStorage.getItem('todo'));
// cucurrentItems.push({
//     title:"mehedi",
//     desc:"mehedi hassan",
// })
/* Loop through localStorage */
// let serial = 1;
// app.forEach((value, index) => {
//     tblBody.innerHTML += `    <tr>
//     <td>${serial}</td>
//     <td>${value.title}</td>
//     <td>${value.desc}</td>
//     <td>
//         <button data-itemId ="${index}" id="editBtn" class="btn btn-edit">Edit</button>
//         <button data-itemId ="${index}" id="dltBtn" class="btn btn-dlt">Delete</button>
//     </td>
//     </tr>
//     `;
//     serial++;
// });